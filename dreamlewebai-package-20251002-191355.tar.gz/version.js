// 🔖 应用版本控制
window.APP_VERSION = '20251001-003948';
window.APP_BUILD_TIME = '2025-10-01 00:39:48';

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('🔖 应用版本:', window.APP_VERSION);
console.log('🕐 构建时间:', window.APP_BUILD_TIME);
console.log('📱 修复内容: 币安刷新问题 + 欧意选择器 + USDT池偏移');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
